const API = location.origin + "/api";

// ======= VERIFICA SE É ADMIN =======
const user = JSON.parse(localStorage.getItem("mvUser"));
if (!user || user.role !== "admin") {
  window.location.href = "index.html";
}

document.getElementById("adminLogout").onclick = () => {
  localStorage.removeItem("mvUser");
  window.location.href = "index.html";
};

// ======= SCHEMAS PARA GERAR FORMULARIOS =======
const SCHEMAS = {
  cliente: {
    title: "Cliente",
    pk: "id_cliente",
    fields: [
      { name: "nome", label: "Nome", type: "text", required: true, max: 100 },
      { name: "email", label: "E-mail", type: "email", required: true, max: 150 },
      { name: "telefone", label: "Telefone (11)", type: "text", max: 11 },
      { name: "cpf", label: "CPF (11)", type: "text", max: 11 },
      { name: "senha_hash", label: "Senha (texto/hash)", type: "text", required: true, max: 255 }
    ]
  },
  restaurante: {
    title: "Restaurante",
    pk: "id_restaurante",
    fields: [
      { name: "nome", label: "Nome", type: "text", required: true, max: 100 },
      { name: "email", label: "E-mail", type: "email", required: true, max: 150 },
      { name: "telefone", label: "Telefone (11)", type: "text", required: true, max: 11 },
      { name: "tipo_cozinha", label: "Tipo de cozinha", type: "text", required: true, max: 50 },
      { name: "endereco", label: "Endereço", type: "text", required: true, max: 255 },
      { name: "senha_hash", label: "Senha (texto/hash)", type: "text", required: true, max: 255 },
      { name: "status", label: "Status", type: "select", options: ["ativo", "inativo"], value: "ativo" }
    ]
  },
  endereco_cliente: {
    title: "Endereço de Cliente",
    pk: "id_endereco",
    fields: [
      { name: "id_cliente", label: "ID Cliente", type: "number", required: true },
      { name: "apelido", label: "Apelido", type: "text", max: 40 },
      { name: "logradouro", label: "Logradouro", type: "text", required: true, max: 140 },
      { name: "numero", label: "Número", type: "text", required: true, max: 12 },
      { name: "complemento", label: "Complemento", type: "text", max: 60 },
      { name: "bairro", label: "Bairro", type: "text", required: true, max: 80 },
      { name: "cidade", label: "Cidade", type: "text", required: true, max: 80 },
      { name: "uf", label: "UF", type: "text", required: true, max: 2 },
      { name: "cep", label: "CEP (8)", type: "text", required: true, max: 8 },
      { name: "referencia", label: "Referência", type: "text", max: 140 },
      { name: "is_principal", label: "Principal?", type: "checkbox" }
    ]
  },
  cardapio_item: {
    title: "Item de Cardápio",
    pk: "id_item",
    fields: [
      { name: "id_restaurante", label: "ID Restaurante", type: "number", required: true },
      { name: "nome", label: "Nome do item", type: "text", required: true, max: 100 },
      { name: "descricao", label: "Descrição", type: "text", max: 255 },
      { name: "categoria", label: "Categoria", type: "text", max: 60 },
      { name: "preco", label: "Preço", type: "number", required: true, step: "0.01" },
      { name: "ativo", label: "Ativo?", type: "checkbox", value: true }
    ]
  },
  pedido: {
    title: "Pedido",
    pk: "id_pedido",
    fields: [
      { name: "id_cliente", label: "ID Cliente", type: "number", required: true },
      { name: "id_restaurante", label: "ID Restaurante", type: "number", required: true },
      { name: "id_endereco", label: "ID Endereço", type: "number" },
      { name: "endereco_texto", label: "Endereço (texto)", type: "text", required: true, max: 255 },
      { name: "observacoes", label: "Observações", type: "text", max: 255 },
      {
        name: "status",
        label: "Status",
        type: "select",
        options: ["novo", "em_preparo", "a_caminho", "entregue", "cancelado"],
        value: "novo"
      },
      { name: "subtotal", label: "Subtotal", type: "number", step: "0.01", value: 0 },
      { name: "taxa_entrega", label: "Taxa de entrega", type: "number", step: "0.01", value: 0 },
      { name: "total", label: "Total", type: "number", step: "0.01", value: 0 }
    ]
  },
  item_pedido: {
    title: "Item de Pedido",
    pk: "id_item_pedido",
    fields: [
      { name: "id_pedido", label: "ID Pedido", type: "number", required: true },
      { name: "id_item", label: "ID Item (cardápio)", type: "number" },
      { name: "nome_item", label: "Nome do item", type: "text", required: true, max: 100 },
      { name: "quantidade", label: "Quantidade", type: "number", required: true, value: 1 },
      { name: "preco_unitario", label: "Preço unitário", type: "number", required: true, step: "0.01" },
      { name: "total_linha", label: "Total da linha", type: "number", step: "0.01" }
    ]
  },
  avaliacao: {
    title: "Avaliação",
    pk: "id_avaliacao",
    fields: [
      { name: "id_pedido", label: "ID Pedido", type: "number", required: true },
      { name: "id_cliente", label: "ID Cliente", type: "number", required: true },
      { name: "id_restaurante", label: "ID Restaurante", type: "number", required: true },
      { name: "nota", label: "Nota (1-5)", type: "number", required: true, min: 1, max: 5, value: 5 },
      { name: "comentario", label: "Comentário", type: "text", max: 255 }
    ]
  }
};

// ======= ELEMENTOS DOM =======
const $entitySelect = document.getElementById("entitySelect");
const $form = document.getElementById("adminForm");
const $formTitle = document.getElementById("formTitle");
const $saveBtn = document.getElementById("saveBtn");
const $cancelEditBtn = document.getElementById("cancelEditBtn");
const $reloadBtn = document.getElementById("reloadBtn");
const $novoBtn = document.getElementById("novoBtn");
const $thead = document.querySelector("#dataTable thead");
const $tbody = document.querySelector("#dataTable tbody");

let currentEntity = "cliente";
let editingId = null;

// ======= INIT SELECT DE ENTIDADES =======
function initEntities() {
  Object.keys(SCHEMAS).forEach(k => {
    const op = document.createElement("option");
    op.value = k;
    op.textContent = k;
    $entitySelect.appendChild(op);
  });
  $entitySelect.value = currentEntity;
}
initEntities();

// ======= RENDER FORM =======
function renderForm() {
  const schema = SCHEMAS[currentEntity];
  $formTitle.textContent = editingId
    ? `Editando ${schema.title} #${editingId}`
    : `Novo ${schema.title}`;

  $form.innerHTML = "";

  for (const f of schema.fields) {
    const row = document.createElement("div");
    row.className = "form-row";

    const label = document.createElement("label");
    label.textContent = f.label;
    label.htmlFor = f.name;

    let input;
    if (f.type === "select") {
      input = document.createElement("select");
      (f.options || []).forEach(v => {
        const op = document.createElement("option");
        op.value = v;
        op.textContent = v;
        input.appendChild(op);
      });
      if (f.value !== undefined) input.value = f.value;
    } else if (f.type === "checkbox") {
      input = document.createElement("input");
      input.type = "checkbox";
      input.checked = !!f.value;
    } else {
      input = document.createElement("input");
      input.type = f.type || "text";
      if (f.max) input.maxLength = f.max;
      if (f.min !== undefined) input.min = f.min;
      if (f.step) input.step = f.step;
      if (f.value !== undefined) input.value = f.value;
    }

    input.id = f.name;
    input.name = f.name;
    if (f.required) input.required = true;

    row.appendChild(label);
    row.appendChild(input);
    $form.appendChild(row);
  }
}

// ======= CARREGAR TABELA =======
async function loadTable() {
  const res = await fetch(`${API}/admin/${currentEntity}?limit=200`);
  const data = await res.json();

  $thead.innerHTML = "";
  const trh = document.createElement("tr");

  if (data.length) {
    Object.keys(data[0]).forEach(k => {
      const th = document.createElement("th");
      th.textContent = k;
      trh.appendChild(th);
    });
  }

  const tha = document.createElement("th");
  tha.textContent = "Ações";
  trh.appendChild(tha);
  $thead.appendChild(trh);

  $tbody.innerHTML = "";
  data.forEach(row => {
    const tr = document.createElement("tr");
    Object.keys(row).forEach(k => {
      const td = document.createElement("td");
      td.textContent = row[k];
      tr.appendChild(td);
    });

    const tda = document.createElement("td");
    const be = document.createElement("button");
    be.textContent = "Editar";
    be.className = "small";
    be.onclick = () => startEdit(row[SCHEMAS[currentEntity].pk]);

    const bd = document.createElement("button");
    bd.textContent = "Excluir";
    bd.className = "small danger";
    bd.onclick = () => removeRow(row[SCHEMAS[currentEntity].pk]);

    tda.appendChild(be);
    tda.appendChild(bd);
    tr.appendChild(tda);
    $tbody.appendChild(tr);
  });
}

// ======= COLETAR FORM =======
function collectForm() {
  const schema = SCHEMAS[currentEntity];
  const obj = {};
  for (const f of schema.fields) {
    const el = document.getElementById(f.name);
    if (!el) continue;

    if (f.type === "checkbox") {
      obj[f.name] = el.checked ? 1 : 0;
    } else if (f.type === "number") {
      obj[f.name] = el.value === "" ? null : Number(el.value);
    } else {
      obj[f.name] = el.value?.trim();
    }
  }
  return obj;
}

// ======= SALVAR =======
async function saveForm(e) {
  e.preventDefault();
  const payload = collectForm();
  const url = editingId
    ? `${API}/admin/${currentEntity}/${editingId}`
    : `${API}/admin/${currentEntity}`;
  const method = editingId ? "PUT" : "POST";

  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const body = await res.json().catch(() => ({}));

  if (!res.ok) {
    alert(`Erro: ${body.error || `${res.status} - falha ao salvar`}`);
    return;
  }

  editingId = null;
  $cancelEditBtn.hidden = true;
  renderForm();
  loadTable();
}

// ======= EDITAR =======
async function startEdit(id) {
  editingId = id;

  const res = await fetch(`${API}/admin/${currentEntity}/${id}`);
  const data = await res.json();

  renderForm();
  const schema = SCHEMAS[currentEntity];

  for (const f of schema.fields) {
    const el = document.getElementById(f.name);
    if (!el) continue;

    if (f.type === "checkbox") {
      el.checked = !!data[f.name];
    } else {
      el.value = data[f.name] ?? "";
    }
  }

  $cancelEditBtn.hidden = false;
}

// ======= EXCLUIR =======
async function removeRow(id) {
  if (!confirm("Confirma exclusão deste registro?")) return;

  const res = await fetch(`${API}/admin/${currentEntity}/${id}`, {
    method: "DELETE"
  });

  const body = await res.json().catch(() => ({}));

  if (!res.ok) {
    alert(`Erro: ${body.error || `${res.status} - não foi possível excluir`}`);
    return;
  }

  loadTable();
}

// ======= EVENTOS =======
$entitySelect.addEventListener("change", e => {
  currentEntity = e.target.value;
  editingId = null;
  $cancelEditBtn.hidden = true;
  renderForm();
  loadTable();
});

$saveBtn.addEventListener("click", saveForm);
$cancelEditBtn.addEventListener("click", e => {
  e.preventDefault();
  editingId = null;
  $cancelEditBtn.hidden = true;
  renderForm();
  loadTable();
});

$reloadBtn.addEventListener("click", () => {
  loadTable();
});

$novoBtn.addEventListener("click", () => {
  editingId = null;
  $cancelEditBtn.hidden = true;
  renderForm();
});

// ======= INIT =======
renderForm();
loadTable();
