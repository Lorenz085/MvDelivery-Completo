// public/cadastro.js
const API = location.origin + "/api";

// Elementos gerais
const tipoUsuarioSelect = document.getElementById("tipoUsuario");

// Etapas
const step1 = document.getElementById("step1");
const step2 = document.getElementById("step2");

// Indicadores de etapa
const stepBubble1 = document.getElementById("stepBubble1");
const stepBubble2 = document.getElementById("stepBubble2");

// Formulários
const formStep1 = document.getElementById("cadastroFormStep1");
const formStep2 = document.getElementById("cadastroFormStep2");

// Botões
const btnNext = document.getElementById("btnNext");
const btnBack = document.getElementById("btnBack");
const btnFinish = document.getElementById("btnFinish");

// Campos da etapa 1
const nomeInput = document.getElementById("nome");
const emailInput = document.getElementById("email");
const telefoneInput = document.getElementById("telefone");
const cpfInput = document.getElementById("cpf");
const tipoCozinhaInput = document.getElementById("tipoCozinha");
const senhaInput = document.getElementById("senha");
const senha2Input = document.getElementById("senha2");

// Campos da etapa 2 (endereço)
const cepInput = document.getElementById("cep");
const logradouroInput = document.getElementById("logradouro");
const numeroInput = document.getElementById("numero");
const complementoInput = document.getElementById("complemento");
const bairroInput = document.getElementById("bairro");
const cidadeInput = document.getElementById("cidade");
const ufInput = document.getElementById("uf");
const referenciaInput = document.getElementById("referencia");

// Grupos por tipo
const camposCliente = document.querySelectorAll(".cadastro-cliente");
const camposRestaurante = document.querySelectorAll(".cadastro-restaurante");

// Objeto para acumular dados entre as etapas
let cadastroData = {};

// ================== MÁSCARAS / TRATAMENTO DE INPUT ==================

// Nome: apenas letras (inclui acentos) e espaços
nomeInput.addEventListener("input", (e) => {
  let v = e.target.value || "";
  v = v.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ\s]/g, ""); // remove números e símbolos
  // tira espaços duplos
  v = v.replace(/\s{2,}/g, " ");
  e.target.value = v;
});

// Telefone: apenas dígitos, máximo 11 (DDD + número)
telefoneInput.addEventListener("input", (e) => {
  let v = e.target.value || "";
  v = v.replace(/\D/g, ""); // só dígitos
  if (v.length > 11) v = v.slice(0, 11);
  e.target.value = v;
});

// CPF: apenas dígitos, máximo 11
if (cpfInput) {
  cpfInput.addEventListener("input", (e) => {
    let v = e.target.value || "";
    v = v.replace(/\D/g, "");
    if (v.length > 11) v = v.slice(0, 11);
    e.target.value = v;
  });
}

// CEP: apenas dígitos, máximo 8
cepInput.addEventListener("input", (e) => {
  let v = e.target.value || "";
  v = v.replace(/\D/g, "");
  if (v.length > 8) v = v.slice(0, 8);
  e.target.value = v;
});

// UF: apenas letras, 2 caracteres, sempre maiúsculo
ufInput.addEventListener("input", (e) => {
  let v = e.target.value || "";
  v = v.replace(/[^A-Za-z]/g, "").toUpperCase();
  if (v.length > 2) v = v.slice(0, 2);
  e.target.value = v;
});

// ================== TOGGLE DE CAMPOS POR TIPO ==================
function atualizarCamposPorTipo() {
  const tipo = tipoUsuarioSelect.value;

  if (tipo === "cliente") {
    camposCliente.forEach(el => el.classList.remove("hidden"));
    camposRestaurante.forEach(el => el.classList.add("hidden"));
  } else {
    camposCliente.forEach(el => el.classList.add("hidden"));
    camposRestaurante.forEach(el => el.classList.remove("hidden"));
  }
}

tipoUsuarioSelect.addEventListener("change", atualizarCamposPorTipo);
atualizarCamposPorTipo();

// ================== NAVEGAÇÃO DE ETAPAS ==================
function irParaStep(stepNumber) {
  if (stepNumber === 1) {
    step1.classList.remove("hidden");
    step2.classList.add("hidden");

    stepBubble1.style.background = "#22c55e";
    stepBubble1.style.color = "#0b1120";
    stepBubble2.style.background = "#111827";
    stepBubble2.style.color = "#6b7280";
  } else {
    step1.classList.add("hidden");
    step2.classList.remove("hidden");

    stepBubble1.style.background = "#111827";
    stepBubble1.style.color = "#6b7280";
    stepBubble2.style.background = "#22c55e";
    stepBubble2.style.color = "#0b1120";
  }
}

// ================== VALIDAÇÃO DA ETAPA 1 ==================
function validarEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function validarStep1() {
  const tipo = tipoUsuarioSelect.value;
  const nome = nomeInput.value.trim();
  const email = emailInput.value.trim().toLowerCase();
  const telefone = telefoneInput.value.trim();
  const cpf = cpfInput.value.trim();
  const tipoCozinha = tipoCozinhaInput.value.trim();
  const senha = senhaInput.value;
  const senha2 = senha2Input.value;

  if (!nome || !email || !telefone || !senha || !senha2) {
    alert("Preencha todos os campos obrigatórios.");
    return false;
  }

  if (!validarEmail(email)) {
    alert("Informe um e-mail válido.");
    return false;
  }

  if (telefone.length < 10 || telefone.length > 11) {
    alert("Informe um telefone válido (DDD + número, 10 ou 11 dígitos).");
    return false;
  }

  if (senha.length < 6) {
    alert("A senha deve ter pelo menos 6 caracteres.");
    return false;
  }

  if (senha !== senha2) {
    alert("As senhas não conferem.");
    return false;
  }

  if (tipo === "cliente") {
    if (!cpf || cpf.length !== 11) {
      alert("Informe um CPF com 11 dígitos (apenas números).");
      return false;
    }
  } else if (tipo === "restaurante") {
    if (!tipoCozinha) {
      alert("Informe o tipo de cozinha do restaurante.");
      return false;
    }
  }

  return true;
}

// ================== BOTÃO "CONTINUAR" (STEP 1 -> STEP 2) ==================
btnNext.addEventListener("click", (e) => {
  e.preventDefault();

  if (!validarStep1()) return;

  const tipo = tipoUsuarioSelect.value;

  cadastroData = {
    tipoUsuario: tipo,
    nome: nomeInput.value.trim(),
    email: emailInput.value.trim().toLowerCase(),
    telefone: telefoneInput.value.trim(),
    senha: senhaInput.value
  };

  if (tipo === "cliente") {
    cadastroData.cpf = cpfInput.value.trim();
  } else {
    cadastroData.tipoCozinha = tipoCozinhaInput.value.trim();
  }

  irParaStep(2);
});

// ================== BOTÃO "VOLTAR" (STEP 2 -> STEP 1) ==================
btnBack.addEventListener("click", (e) => {
  e.preventDefault();
  irParaStep(1);
});

// ================== ETAPA 2: ENVIO FINAL (ENDEREÇO) ==================
formStep2.addEventListener("submit", async (e) => {
  e.preventDefault();

  let cep = (cepInput.value || "").trim().replace(/\D/g, "");
  const logradouro = logradouroInput.value.trim();
  const numero = numeroInput.value.trim();
  const complemento = complementoInput.value.trim();
  const bairro = bairroInput.value.trim();
  const cidade = cidadeInput.value.trim();
  const uf = ufInput.value.trim().toUpperCase();
  const referencia = referenciaInput.value.trim();

  if (!cep || cep.length !== 8) {
    alert("Informe um CEP com 8 dígitos (apenas números).");
    return;
  }

  if (!logradouro || !numero || !bairro || !cidade || !uf) {
    alert("Preencha todos os campos obrigatórios do endereço.");
    return;
  }

  if (uf.length !== 2) {
    alert("UF deve ter 2 letras (ex.: CE, SP).");
    return;
  }

  // Monta endereço completo em texto (para o campo simples do banco)
  const enderecoFormatado =
    `${logradouro}, ${numero}` +
    (complemento ? ` - ${complemento}` : "") +
    `, ${bairro}, ${cidade} - ${uf}` +
    `, CEP ${cep}` +
    (referencia ? ` (Ref.: ${referencia})` : "");

  const payload = {
    ...cadastroData,
    endereco: enderecoFormatado,
    cep,
    logradouro,
    numero,
    complemento: complemento || null,
    bairro,
    cidade,
    uf,
    referencia: referencia || null
  };

  try {
    btnFinish.disabled = true;
    btnFinish.textContent = "Criando conta...";

    const res = await fetch(`${API}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const body = await res.json().catch(() => ({}));

    if (!res.ok) {
      alert(body.error || "Erro ao criar conta. Verifique os dados e tente novamente.");
      btnFinish.disabled = false;
      btnFinish.textContent = "Criar conta";
      return;
    }

    alert("Conta criada com sucesso! Faça login para continuar.");
    window.location.href = "index.html";
  } catch (err) {
    console.error("Erro no cadastro:", err);
    alert("Erro ao conectar com o servidor.");
    btnFinish.disabled = false;
    btnFinish.textContent = "Criar conta";
  }
});
