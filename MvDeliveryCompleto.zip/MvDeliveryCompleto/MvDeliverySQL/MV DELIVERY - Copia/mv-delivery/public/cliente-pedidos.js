const API = location.origin + "/api";

// ======= VERIFICA SE É CLIENTE =======
const user = JSON.parse(localStorage.getItem("mvUser"));
if (!user || user.role !== "cliente") {
  window.location.href = "index.html";
}

document.getElementById("clienteNome").textContent = user.nome;
document.getElementById("logoutBtn").onclick = () => {
  localStorage.removeItem("mvUser");
  window.location.href = "index.html";
};

// ===== ELEMENTOS =====
const listaPedidos = document.getElementById("listaPedidosCliente");
const detalheCard = document.getElementById("detalhePedidoCliente");

let pedidos = [];
let pedidoSelecionadoId = null; // para manter o detalhe aberto atualizado

// ========== CARREGAR PEDIDOS DO CLIENTE ==========
async function carregarPedidosCliente() {
  try {
    const res = await fetch(`${API}/pedidos?cliente=${user.id}`);
    if (!res.ok) {
      console.error("Erro ao buscar pedidos do cliente");
      listaPedidos.innerHTML =
        `<p class="text-muted">Erro ao carregar pedidos.</p>`;
      return;
    }

    pedidos = await res.json();
    renderListaPedidosCliente();

    // Se já tiver um pedido selecionado, atualiza o detalhe dele
    if (pedidoSelecionadoId) {
      const existe = pedidos.find(p => p.id_pedido === pedidoSelecionadoId);
      if (existe) {
        abrirDetalhePedido(pedidoSelecionadoId, /*silent*/ true);
      } else {
        // Se o pedido sumiu da lista, limpa seleção
        pedidoSelecionadoId = null;
        detalheCard.innerHTML =
          `<p class="text-muted">Selecione um pedido à esquerda para ver os detalhes.</p>`;
      }
    }

  } catch (err) {
    console.error("Erro carregarPedidosCliente", err);
    listaPedidos.innerHTML =
      `<p class="text-muted">Erro ao carregar pedidos.</p>`;
  }
}

// primeira carga
carregarPedidosCliente();

// atualiza automaticamente a cada 5 segundos
setInterval(carregarPedidosCliente, 5000);

// ========== LISTAR PEDIDOS ==========
function renderListaPedidosCliente() {
  listaPedidos.innerHTML = "";

  if (!pedidos.length) {
    listaPedidos.innerHTML =
      `<p class="text-muted">Você ainda não realizou nenhum pedido.</p>`;
    return;
  }

  pedidos.forEach(p => {
    const totalNum = Number(p.total || 0);
    const data = new Date(p.data_hora);

    const card = document.createElement("div");
    card.className = "pedido-card";

    // destaca o pedido selecionado
    if (p.id_pedido === pedidoSelecionadoId) {
      card.classList.add("pedido-card-selected");
    }

    card.innerHTML = `
      <div class="pedido-header">
        <strong>#${p.codigo_pedido || p.id_pedido}</strong>
        <span class="pedido-status ${p.status}">${p.status}</span>
      </div>
      <div class="pedido-body">
        Restaurante: ${p.nome_restaurante}<br/>
        Total: R$ ${totalNum.toFixed(2)}<br/>
        ${data.toLocaleString()}
      </div>
    `;

    card.onclick = () => {
      pedidoSelecionadoId = p.id_pedido;
      abrirDetalhePedido(p.id_pedido);
      renderListaPedidosCliente(); // re-renderiza para aplicar highlight
    };

    listaPedidos.appendChild(card);
  });
}

// ========== ABRIR DETALHES DO PEDIDO ==========
async function abrirDetalhePedido(id_pedido, silent = false) {
  try {
    const res = await fetch(`${API}/pedidos/${id_pedido}`);
    if (!res.ok) {
      if (!silent) {
        detalheCard.innerHTML =
          `<p class="text-muted">Erro ao carregar detalhes do pedido.</p>`;
      }
      return;
    }

    const data = await res.json();
    const pedido = data.pedido;
    const itens = data.itens || [];

    const subtotalNum = Number(pedido.subtotal || 0);
    const taxaNum = Number(pedido.taxa_entrega || 0);
    const totalNum = Number(pedido.total || 0);

    detalheCard.innerHTML = `
      <h3>Pedido #${pedido.codigo_pedido || pedido.id_pedido}</h3>
      <p>
        <strong>Restaurante:</strong> ${pedido.nome_restaurante}<br/>
        <strong>Status:</strong> ${pedido.status}<br/>
        <strong>Data:</strong> ${new Date(pedido.data_hora).toLocaleString()}<br/>
        <strong>Endereço:</strong> ${pedido.endereco_texto}<br/>
        <strong>Observações:</strong> ${pedido.observacoes || "Nenhuma"}<br/>
      </p>

      <h4>Itens</h4>
      ${
        itens.length
          ? itens
              .map(i => {
                const linhaNum = Number(
                  i.total_linha ||
                    (i.preco_unitario * i.quantidade) ||
                    0
                );
                return `
                  <div class="carrinho-item">
                    <span>${i.quantidade}x ${i.nome_item}</span>
                    <strong>R$ ${linhaNum.toFixed(2)}</strong>
                  </div>
                `;
              })
              .join("")
          : '<p class="text-muted">Nenhum item encontrado.</p>'
      }

      <h4 class="mt-12">Totais</h4>
      <div class="pedido-body">
        Subtotal: R$ ${subtotalNum.toFixed(2)}<br/>
        Taxa de entrega: R$ ${taxaNum.toFixed(2)}<br/>
        <strong>Total: R$ ${totalNum.toFixed(2)}</strong>
      </div>
    `;
  } catch (err) {
    console.error("Erro abrirDetalhePedido", err);
    if (!silent) {
      detalheCard.innerHTML =
        `<p class="text-muted">Erro ao carregar detalhes do pedido.</p>`;
    }
  }
}
