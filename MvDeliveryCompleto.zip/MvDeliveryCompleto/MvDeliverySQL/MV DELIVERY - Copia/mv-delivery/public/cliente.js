// public/cliente.js
const API = location.origin + "/api";

// ------- Sessão do usuário -------
const user = JSON.parse(localStorage.getItem("mvUser"));
if (!user || user.role !== "cliente") {
  window.location.href = "index.html";
}

document.getElementById("clienteNome").textContent = user.nome;
document.getElementById("logoutBtn").onclick = () => {
  localStorage.removeItem("mvUser");
  window.location.href = "index.html";
};

// ------- ELEMENTOS -------
const secRest = document.getElementById("secRestaurantes");
const secCard = document.getElementById("secCardapio");
const listaRestaurantes = document.getElementById("listaRestaurantes");
const listaCardapio = document.getElementById("listaCardapio");
const carrinhoLista = document.getElementById("carrinhoLista");
const carrinhoSubtotal = document.getElementById("carrinhoSubtotal");
const carrinhoEntrega = document.getElementById("carrinhoEntrega");
const carrinhoTotal = document.getElementById("carrinhoTotal");
const restauranteTitulo = document.getElementById("restauranteTitulo");
const voltarRest = document.getElementById("voltarRestaurantes");
const btnCheckout = document.getElementById("btnCheckout");

let restauranteSelecionado = null;
let carrinho = [];

// ------- LISTAR RESTAURANTES -------
async function carregarRestaurantes() {
  try {
    const res = await fetch(`${API}/restaurantes`);
    if (!res.ok) {
      console.error("Erro ao buscar restaurantes");
      return;
    }
    const lista = await res.json();

    listaRestaurantes.innerHTML = "";

    if (!lista.length) {
      listaRestaurantes.innerHTML =
        `<p class="text-muted">Nenhum restaurante ativo no momento.</p>`;
      return;
    }

    lista.forEach(r => {
      const div = document.createElement("div");
      div.className = "rest-card";
      div.innerHTML = `
        <div class="rest-name">${r.nome}</div>
        <div class="rest-meta">${r.tipo_cozinha}</div>
        <div class="rest-meta">${r.endereco}</div>
      `;
      div.onclick = () => selecionarRestaurante(r);
      listaRestaurantes.appendChild(div);
    });
  } catch (err) {
    console.error("Erro carregarRestaurantes", err);
  }
}

carregarRestaurantes();

// ------- ABRIR CARDÁPIO -------
async function selecionarRestaurante(rest) {
  restauranteSelecionado = rest;

  secRest.classList.add("hidden");
  secCard.classList.remove("hidden");

  restauranteTitulo.textContent = rest.nome;
  carrinho = [];
  atualizarCarrinho();

  try {
    const res = await fetch(`${API}/cardapio/restaurante/${rest.id_restaurante}`);
    if (!res.ok) {
      console.error("Erro ao buscar cardápio do restaurante");
      listaCardapio.innerHTML =
        `<p class="text-muted">Erro ao carregar cardápio.</p>`;
      return;
    }

    const itens = await res.json();

    listaCardapio.innerHTML = "";

    if (!itens.length) {
      listaCardapio.innerHTML =
        `<p class="text-muted">Este restaurante ainda não cadastrou itens.</p>`;
      return;
    }

    itens.forEach(item => {
      const precoNum = Number(item.preco); // DECIMAL vem como string
      const div = document.createElement("div");
      div.className = "cardapio-item";

      div.innerHTML = `
        <div class="cardapio-info">
          <div class="cardapio-nome">${item.nome}</div>
          <div class="cardapio-desc">${item.descricao || ""}</div>
          <div class="cardapio-preco">R$ ${precoNum.toFixed(2)}</div>
        </div>
        <button class="small">Adicionar</button>
      `;

      div.querySelector("button").onclick = () => addCarrinho(item);

      listaCardapio.appendChild(div);
    });
  } catch (err) {
    console.error("Erro selecionarRestaurante", err);
    listaCardapio.innerHTML =
      `<p class="text-muted">Erro ao carregar cardápio.</p>`;
  }
}

voltarRest.onclick = () => {
  secCard.classList.add("hidden");
  secRest.classList.remove("hidden");
};

// ------- CARRINHO -------

// adiciona item (incrementa se já existir)
function addCarrinho(item) {
  const precoNum = Number(item.preco);
  const existente = carrinho.find(i => i.id_item === item.id_item);

  if (existente) {
    existente.quantidade++;
  } else {
    carrinho.push({
      id_item: item.id_item,
      nome_item: item.nome,
      preco_unitario: precoNum,
      quantidade: 1
    });
  }
  atualizarCarrinho();
}

function atualizarCarrinho() {
  carrinhoLista.innerHTML = "";

  let subtotal = 0;

  carrinho.forEach(it => {
    const linhaTotal = it.preco_unitario * it.quantidade;
    subtotal += linhaTotal;

    const div = document.createElement("div");
    div.className = "carrinho-item";

    // Topo: nome + total
    const topo = document.createElement("div");
    topo.style.display = "flex";
    topo.style.justifyContent = "space-between";
    topo.style.alignItems = "center";

    topo.innerHTML = `
      <span>${it.nome_item}</span>
      <strong>R$ ${linhaTotal.toFixed(2)}</strong>
    `;

    // Controles de quantidade (– qty +)
    const controls = document.createElement("div");
    controls.style.display = "flex";
    controls.style.alignItems = "center";
    controls.style.gap = "10px";
    controls.style.marginTop = "6px";

    // Botão diminuir
    const btnMenos = document.createElement("button");
    btnMenos.textContent = "−";
    btnMenos.style.cssText = `
      width:32px;height:32px;font-size:20px;
      border-radius:8px;border:none;cursor:pointer;
      background:#334155;color:white;
    `;
    btnMenos.onclick = () => {
      if (it.quantidade > 1) {
        it.quantidade--;
      } else {
        // remove se chegar em 0
        carrinho = carrinho.filter(x => x.id_item !== it.id_item);
      }
      atualizarCarrinho();
    };

    // Quantidade
    const qty = document.createElement("div");
    qty.textContent = it.quantidade;
    qty.style.cssText = `
      width:32px;height:32px;
      display:flex;align-items:center;justify-content:center;
      background:#1e293b;color:white;border-radius:8px;
      font-weight:bold;
    `;

    // Botão aumentar
    const btnMais = document.createElement("button");
    btnMais.textContent = "+";
    btnMais.style.cssText = `
      width:32px;height:32px;font-size:20px;
      border-radius:8px;border:none;cursor:pointer;
      background:#16a34a;color:white;
    `;
    btnMais.onclick = () => {
      it.quantidade++;
      atualizarCarrinho();
    };

    controls.appendChild(btnMenos);
    controls.appendChild(qty);
    controls.appendChild(btnMais);

    div.appendChild(topo);
    div.appendChild(controls);
    carrinhoLista.appendChild(div);
  });

  carrinhoSubtotal.textContent = subtotal.toFixed(2);
  const entrega = Number(carrinhoEntrega.textContent || 0);
  carrinhoTotal.textContent = (subtotal + entrega).toFixed(2);
}

// ------- CHECKOUT USANDO ENDEREÇO CADASTRADO -------
btnCheckout.onclick = async () => {
  if (!carrinho.length) {
    alert("Seu carrinho está vazio.");
    return;
  }

  // Busca endereço do cliente
  let enderecoBase = null;

  try {
    const res = await fetch(`${API}/enderecos?cliente=${user.id}`);
    if (!res.ok) {
      alert("Não foi possível buscar seu endereço. Tente novamente.");
      return;
    }

    const enderecos = await res.json();

    if (!Array.isArray(enderecos) || !enderecos.length) {
      alert("Nenhum endereço encontrado para sua conta. Refaça o cadastro.");
      return;
    }

    // Pega o principal ou o primeiro
    enderecoBase =
      enderecos.find(e => e.is_principal === 1 || e.is_principal === true) ||
      enderecos[0];
  } catch (err) {
    console.error("Erro ao buscar endereços", err);
    alert("Erro ao buscar seu endereço. Tente novamente.");
    return;
  }

  const enderecoTexto =
    `${enderecoBase.logradouro}, ${enderecoBase.numero}` +
    (enderecoBase.complemento ? ` - ${enderecoBase.complemento}` : "") +
    `, ${enderecoBase.bairro}, ${enderecoBase.cidade} - ${enderecoBase.uf}, ` +
    `CEP ${enderecoBase.cep}` +
    (enderecoBase.referencia ? ` (Ref.: ${enderecoBase.referencia})` : "");

  const payload = {
    id_cliente: user.id,
    id_restaurante: restauranteSelecionado.id_restaurante,
    endereco_texto: enderecoTexto,
    id_endereco: enderecoBase.id_endereco,
    observacoes: "",
    taxa_entrega: Number(carrinhoEntrega.textContent || 0),
    itens: carrinho
  };

  try {
    const res = await fetch(`${API}/pedidos/checkout`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const body = await res.json();

    if (!res.ok) {
      alert(body.error || "Erro ao finalizar pedido.");
      return;
    }

    alert(`Pedido realizado! Código: ${body.codigo_pedido}`);
    window.location.reload();
  } catch (err) {
    console.error(err);
    alert("Erro ao conectar com o servidor.");
  }
};
