// backend/src/enderecoRoutes.js
import express from "express";
import { pool } from "./db.js";

export const enderecoRouter = express.Router();

/**
 * GET /api/enderecos?cliente=ID
 * Lista endereços de um cliente
 */
enderecoRouter.get("/", async (req, res) => {
  const { cliente } = req.query;

  if (!cliente) {
    return res.status(400).json({ error: "Parâmetro 'cliente' é obrigatório." });
  }

  try {
    const [rows] = await pool.query(
      `SELECT
         id_endereco,
         id_cliente,
         apelido,
         logradouro,
         numero,
         complemento,
         bairro,
         cidade,
         uf,
         cep,
         referencia,
         is_principal
       FROM endereco_cliente         -- <<<<< TABELA CORRETA
       WHERE id_cliente = ?
       ORDER BY is_principal DESC, created_at DESC`,
      [cliente]
    );
    res.json(rows);
  } catch (err) {
    console.error("GET /enderecos", err);
    res.status(500).json({ error: "Erro ao listar endereços." });
  }
});

/**
 * POST /api/enderecos
 * Cria um endereço para o cliente
 */
enderecoRouter.post("/", async (req, res) => {
  const {
    id_cliente,
    apelido,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    uf,
    cep,
    referencia,
    is_principal
  } = req.body;

  if (!id_cliente || !logradouro || !numero || !bairro || !cidade || !uf || !cep) {
    return res.status(400).json({
      error:
        "id_cliente, logradouro, numero, bairro, cidade, uf e cep são obrigatórios."
    });
  }

  try {
    const [r] = await pool.query(
      `INSERT INTO endereco_cliente
       (id_cliente, apelido, logradouro, numero, complemento,
        bairro, cidade, uf, cep, referencia, is_principal)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [
        id_cliente,
        apelido || null,
        logradouro,
        numero,
        complemento || null,
        bairro,
        cidade,
        uf,
        cep,
        referencia || null,
        is_principal ? 1 : 0
      ]
    );

    res.status(201).json({ id_endereco: r.insertId });
  } catch (err) {
    console.error("POST /enderecos", err);
    res.status(500).json({ error: "Erro ao criar endereço." });
  }
});

/**
 * PUT /api/enderecos/:id_endereco
 * Atualiza um endereço
 */
enderecoRouter.put("/:id_endereco", async (req, res) => {
  const { id_endereco } = req.params;
  const {
    apelido,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    uf,
    cep,
    referencia,
    is_principal
  } = req.body;

  try {
    const [r] = await pool.query(
      `UPDATE endereco_cliente
       SET apelido = ?,
           logradouro = ?,
           numero = ?,
           complemento = ?,
           bairro = ?,
           cidade = ?,
           uf = ?,
           cep = ?,
           referencia = ?,
           is_principal = ?
       WHERE id_endereco = ?`,
      [
        apelido || null,
        logradouro,
        numero,
        complemento || null,
        bairro,
        cidade,
        uf,
        cep,
        referencia || null,
        is_principal ? 1 : 0,
        id_endereco
      ]
    );

    if (!r.affectedRows) {
      return res.status(404).json({ error: "Endereço não encontrado." });
    }

    res.json({ ok: true });
  } catch (err) {
    console.error("PUT /enderecos/:id", err);
    res.status(500).json({ error: "Erro ao atualizar endereço." });
  }
});

/**
 * PATCH /api/enderecos/:id_endereco/principal
 * Define este endereço como principal, zerando os outros do cliente
 */
enderecoRouter.patch("/:id_endereco/principal", async (req, res) => {
  const { id_endereco } = req.params;

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Descobre o cliente do endereço
    const [rows] = await conn.query(
      `SELECT id_cliente FROM endereco_cliente WHERE id_endereco = ?`,
      [id_endereco]
    );

    if (!rows.length) {
      await conn.rollback();
      conn.release();
      return res.status(404).json({ error: "Endereço não encontrado." });
    }

    const id_cliente = rows[0].id_cliente;

    // Zera outros principais
    await conn.query(
      `UPDATE endereco_cliente
       SET is_principal = 0
       WHERE id_cliente = ?`,
      [id_cliente]
    );

    // Marca este como principal
    await conn.query(
      `UPDATE endereco_cliente
       SET is_principal = 1
       WHERE id_endereco = ?`,
      [id_endereco]
    );

    await conn.commit();
    conn.release();
    res.json({ ok: true });
  } catch (err) {
    await conn.rollback();
    conn.release();
    console.error("PATCH /enderecos/:id/principal", err);
    res.status(500).json({ error: "Erro ao definir principal." });
  }
});

/**
 * DELETE /api/enderecos/:id_endereco
 * Remove um endereço
 */
enderecoRouter.delete("/:id_endereco", async (req, res) => {
  const { id_endereco } = req.params;

  try {
    const [r] = await pool.query(
      `DELETE FROM endereco_cliente WHERE id_endereco = ?`,
      [id_endereco]
    );

    if (!r.affectedRows) {
      return res.status(404).json({ error: "Endereço não encontrado." });
    }

    res.json({ ok: true });
  } catch (err) {
    console.error("DELETE /enderecos/:id", err);
    res.status(500).json({ error: "Erro ao excluir endereço." });
  }
});
