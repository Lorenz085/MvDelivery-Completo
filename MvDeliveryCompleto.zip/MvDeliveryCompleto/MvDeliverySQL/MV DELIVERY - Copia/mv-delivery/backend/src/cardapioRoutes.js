// backend/src/cardapioRoutes.js
import express from "express";
import { pool } from "./db.js";

export const cardapioRouter = express.Router();

/**
 * GET /api/cardapio/restaurante/:id_restaurante
 * Lista itens do cardápio de um restaurante
 */
cardapioRouter.get("/restaurante/:id_restaurante", async (req, res) => {
  const { id_restaurante } = req.params;

  try {
    const [rows] = await pool.query(
      `SELECT id_item, id_restaurante, nome, descricao, categoria, preco, ativo
       FROM cardapio_item
       WHERE id_restaurante = ?
       ORDER BY nome`,
      [id_restaurante]
    );
    res.json(rows);
  } catch (err) {
    console.error("GET /cardapio/restaurante", err);
    res.status(500).json({ error: "Erro ao listar itens de cardápio." });
  }
});

/**
 * GET /api/cardapio/:id_item
 * Detalhes de um item específico
 */
cardapioRouter.get("/:id_item", async (req, res) => {
  const { id_item } = req.params;

  try {
    const [rows] = await pool.query(
      `SELECT id_item, id_restaurante, nome, descricao, categoria, preco, ativo
       FROM cardapio_item
       WHERE id_item = ?`,
      [id_item]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Item de cardápio não encontrado." });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error("GET /cardapio/:id_item", err);
    res.status(500).json({ error: "Erro ao buscar item de cardápio." });
  }
});

/**
 * POST /api/cardapio
 * Cria um novo item de cardápio
 * body: { id_restaurante, nome, descricao, categoria, preco, ativo }
 */
cardapioRouter.post("/", async (req, res) => {
  const { id_restaurante, nome, descricao, categoria, preco, ativo } = req.body;

  if (!id_restaurante || !nome || preco == null) {
    return res
      .status(400)
      .json({ error: "id_restaurante, nome e preco são obrigatórios." });
  }

  try {
    const [r] = await pool.query(
      `INSERT INTO cardapio_item
       (id_restaurante, nome, descricao, categoria, preco, ativo)
       VALUES (?,?,?,?,?,?)`,
      [
        id_restaurante,
        nome,
        descricao || null,
        categoria || null,
        preco,
        ativo != null ? ativo : 1
      ]
    );

    res.status(201).json({ id_item: r.insertId });
  } catch (err) {
    console.error("POST /cardapio", err);
    res.status(500).json({ error: "Erro ao criar item de cardápio." });
  }
});

/**
 * PUT /api/cardapio/:id_item
 * Atualiza um item de cardápio
 */
cardapioRouter.put("/:id_item", async (req, res) => {
  const { id_item } = req.params;
  const { nome, descricao, categoria, preco, ativo } = req.body;

  const sets = [];
  const vals = [];

  if (nome !== undefined) {
    sets.push("nome = ?");
    vals.push(nome);
  }
  if (descricao !== undefined) {
    sets.push("descricao = ?");
    vals.push(descricao);
  }
  if (categoria !== undefined) {
    sets.push("categoria = ?");
    vals.push(categoria);
  }
  if (preco !== undefined) {
    sets.push("preco = ?");
    vals.push(preco);
  }
  if (ativo !== undefined) {
    sets.push("ativo = ?");
    vals.push(ativo);
  }

  if (!sets.length) {
    return res.status(400).json({ error: "Nenhum campo para atualizar." });
  }

  vals.push(id_item);

  try {
    const [r] = await pool.query(
      `UPDATE cardapio_item
       SET ${sets.join(", ")}
       WHERE id_item = ?`,
      vals
    );

    if (!r.affectedRows) {
      return res.status(404).json({ error: "Item de cardápio não encontrado." });
    }

    res.json({ ok: true });
  } catch (err) {
    console.error("PUT /cardapio/:id_item", err);
    res.status(500).json({ error: "Erro ao atualizar item de cardápio." });
  }
});

/**
 * DELETE /api/cardapio/:id_item
 * Remove um item de cardápio
 */
cardapioRouter.delete("/:id_item", async (req, res) => {
  const { id_item } = req.params;

  try {
    const [r] = await pool.query(
      `DELETE FROM cardapio_item WHERE id_item = ?`,
      [id_item]
    );
    if (!r.affectedRows) {
      return res.status(404).json({ error: "Item de cardápio não encontrado." });
    }
    res.json({ ok: true });
  } catch (err) {
    console.error("DELETE /cardapio/:id_item", err);
    res.status(500).json({ error: "Erro ao remover item de cardápio." });
  }
});
