import express from "express";
import { pool } from "./db.js";

export const restauranteRouter = express.Router();

// Lista de restaurantes (para cliente ver na home)
restauranteRouter.get("/", async (req, res) => {
  const [rows] = await pool.query(
    `SELECT id_restaurante,nome,tipo_cozinha,endereco
     FROM restaurante
     WHERE status = 'ativo'
     ORDER BY nome`
  );
  res.json(rows);
});

// Detalhes de um restaurante
restauranteRouter.get("/:id", async (req, res) => {
  const { id } = req.params;
  const [rows] = await pool.query(
    "SELECT id_restaurante,nome,tipo_cozinha,endereco FROM restaurante WHERE id_restaurante = ?",
    [id]
  );
  if (!rows.length) return res.status(404).json({ error: "Restaurante não encontrado." });
  res.json(rows[0]);
});
