import express from "express";
import { pool } from "./db.js";

export const clienteRouter = express.Router();

// Buscar dados de um cliente
clienteRouter.get("/:id", async (req, res) => {
  const { id } = req.params;
  const [rows] = await pool.query(
    "SELECT id_cliente, nome, email, telefone FROM cliente WHERE id_cliente = ?",
    [id]
  );
  if (!rows.length) return res.status(404).json({ error: "Cliente não encontrado." });
  res.json(rows[0]);
});

// Endereços de um cliente
clienteRouter.get("/:id/enderecos", async (req, res) => {
  const { id } = req.params;
  const [rows] = await pool.query(
    "SELECT * FROM endereco_cliente WHERE id_cliente = ? ORDER BY is_principal DESC, id_endereco DESC",
    [id]
  );
  res.json(rows);
});

clienteRouter.post("/:id/enderecos", async (req, res) => {
  const { id } = req.params;
  const {
    apelido, logradouro, numero, complemento,
    bairro, cidade, uf, cep, referencia, is_principal
  } = req.body;

  try {
    const [r] = await pool.query(
      `INSERT INTO endereco_cliente
       (id_cliente,apelido,logradouro,numero,complemento,bairro,cidade,uf,cep,referencia,is_principal)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [
        id, apelido || null, logradouro, numero, complemento || null,
        bairro, cidade, uf, cep, referencia || null, is_principal ? 1 : 0
      ]
    );
    res.status(201).json({ id_endereco: r.insertId });
  } catch (err) {
    console.error("POST /enderecos", err);
    res.status(500).json({ error: "Erro ao salvar endereço." });
  }
});
