// backend/src/authRoutes.js
import express from "express";
import { pool } from "./db.js";

export const authRouter = express.Router();

/* ===================== HELPERS ===================== */

function sanitizeString(str) {
  return (str || "").toString().trim();
}

function onlyDigits(str) {
  return (str || "").toString().replace(/\D/g, "");
}

function isValidEmail(email) {
  const e = sanitizeString(email).toLowerCase();
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(e);
}

/**
 * Cria cliente + endereço principal em transação
 */
async function criarClienteComEndereco(dados) {
  const {
    nome,
    email,
    telefone,
    cpf,
    senha,
    cep,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    uf,
    referencia
  } = dados;

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Insere cliente
    const [rCli] = await conn.query(
      `INSERT INTO cliente (nome,email,telefone,cpf,senha_hash)
       VALUES (?,?,?,?,?)`,
      [
        sanitizeString(nome),
        sanitizeString(email).toLowerCase(),
        onlyDigits(telefone) || null,
        onlyDigits(cpf) || null,
        sanitizeString(senha)
      ]
    );
    const id_cliente = rCli.insertId;

    // Insere endereço principal
    // ATENÇÃO: tabela correta é "endereco_cliente" (sem S)
    const [rEnd] = await conn.query(
      `INSERT INTO endereco_cliente
        (id_cliente,apelido,logradouro,numero,complemento,bairro,cidade,uf,cep,referencia,is_principal)
       VALUES (?,?,?,?,?,?,?,?,?,?,1)`,
      [
        id_cliente,
        "Principal",
        sanitizeString(logradouro),
        sanitizeString(numero),
        complemento ? sanitizeString(complemento) : null,
        sanitizeString(bairro),
        sanitizeString(cidade),
        sanitizeString(uf).toUpperCase(),
        onlyDigits(cep),
        referencia ? sanitizeString(referencia) : null
      ]
    );

    await conn.commit();
    return { id_cliente, id_endereco: rEnd.insertId };
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

/* ===================== CADASTRO UNIFICADO ===================== */
/**
 * Front (cadastro.js) chama: POST /api/auth/register
 */
authRouter.post("/register", async (req, res) => {
  let {
    tipoUsuario,
    nome,
    email,
    telefone,
    cpf,
    tipoCozinha,
    senha,
    endereco,    // texto formatado (restaurante)
    cep,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    uf,
    referencia
  } = req.body;

  tipoUsuario = sanitizeString(tipoUsuario);
  nome = sanitizeString(nome);
  email = sanitizeString(email).toLowerCase();
  telefone = onlyDigits(telefone);
  cpf = onlyDigits(cpf);
  tipoCozinha = sanitizeString(tipoCozinha);
  senha = sanitizeString(senha);
  endereco = sanitizeString(endereco);
  cep = onlyDigits(cep);
  logradouro = sanitizeString(logradouro);
  numero = sanitizeString(numero);
  complemento = complemento ? sanitizeString(complemento) : null;
  bairro = sanitizeString(bairro);
  cidade = sanitizeString(cidade);
  uf = sanitizeString(uf).toUpperCase();
  referencia = referencia ? sanitizeString(referencia) : null;

  if (!tipoUsuario || !nome || !email || !telefone || !senha) {
    return res
      .status(400)
      .json({ error: "Tipo de usuário, nome, e-mail, telefone e senha são obrigatórios." });
  }

  if (!["cliente", "restaurante"].includes(tipoUsuario)) {
    return res.status(400).json({ error: "Tipo de usuário inválido." });
  }

  if (!isValidEmail(email)) {
    return res.status(400).json({ error: "E-mail inválido." });
  }

  if (telefone.length < 10 || telefone.length > 11) {
    return res.status(400).json({ error: "Telefone inválido (use DDD + número, 10 ou 11 dígitos)." });
  }

  if (senha.length < 6) {
    return res.status(400).json({ error: "Senha muito curta. Mínimo 6 caracteres." });
  }

  try {
    /* ---------- CLIENTE ---------- */
    if (tipoUsuario === "cliente") {
      if (!cpf || cpf.length !== 11) {
        return res.status(400).json({
          error: "CPF inválido. Informe 11 dígitos (apenas números)."
        });
      }

      if (!cep || cep.length !== 8 ||
          !logradouro || !numero || !bairro || !cidade || !uf || uf.length !== 2) {
        return res.status(400).json({
          error: "Preencha todos os campos obrigatórios do endereço (CEP, logradouro, número, bairro, cidade, UF)."
        });
      }

      const result = await criarClienteComEndereco({
        nome,
        email,
        telefone,
        cpf,
        senha,
        cep,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        uf,
        referencia
      });

      return res.status(201).json({
        message: "Cliente cadastrado com sucesso.",
        ...result
      });
    }

    /* ---------- RESTAURANTE ---------- */
    if (tipoUsuario === "restaurante") {
      if (!tipoCozinha) {
        return res.status(400).json({
          error: "Tipo de cozinha é obrigatório para restaurante."
        });
      }

      if (!endereco) {
        return res.status(400).json({
          error: "Endereço formatado é obrigatório para restaurante."
        });
      }

      const [r] = await pool.query(
        `INSERT INTO restaurante (nome,email,telefone,tipo_cozinha,endereco,senha_hash)
         VALUES (?,?,?,?,?,?)`,
        [nome, email, telefone, tipoCozinha, endereco, senha]
      );

      return res.status(201).json({
        message: "Restaurante cadastrado com sucesso.",
        id_restaurante: r.insertId
      });
    }

    return res.status(400).json({ error: "Tipo de usuário inválido." });
  } catch (err) {
    console.error("register", err);
    // Tratamento básico de erros de UNIQUE (e-mail duplicado, etc.)
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ error: "Já existe um usuário com este e-mail ou telefone." });
    }
    return res.status(500).json({ error: "Erro ao cadastrar usuário." });
  }
});

/* =============== CADASTROS ESPECÍFICOS (LEGADO, SE PRECISAR) =============== */

// Cadastro cliente simples (sem endereço principal automático)
authRouter.post("/register-cliente", async (req, res) => {
  let { nome, email, telefone, cpf, senha } = req.body;

  nome = sanitizeString(nome);
  email = sanitizeString(email).toLowerCase();
  telefone = onlyDigits(telefone);
  cpf = onlyDigits(cpf);
  senha = sanitizeString(senha);

  if (!nome || !email || !senha) {
    return res.status(400).json({ error: "Nome, e-mail e senha são obrigatórios." });
  }

  if (!isValidEmail(email)) {
    return res.status(400).json({ error: "E-mail inválido." });
  }

  if (telefone && (telefone.length < 10 || telefone.length > 11)) {
    return res.status(400).json({ error: "Telefone inválido." });
  }

  if (cpf && cpf.length !== 11) {
    return res.status(400).json({ error: "CPF inválido (11 dígitos)." });
  }

  if (senha.length < 6) {
    return res.status(400).json({ error: "Senha muito curta. Mínimo 6 caracteres." });
  }

  try {
    const [r] = await pool.query(
      `INSERT INTO cliente (nome,email,telefone,cpf,senha_hash)
       VALUES (?,?,?,?,?)`,
      [nome, email, telefone || null, cpf || null, senha]
    );
    res.status(201).json({ id_cliente: r.insertId });
  } catch (err) {
    console.error("register-cliente", err);
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ error: "Já existe um cliente com este e-mail." });
    }
    res.status(500).json({ error: "Erro ao cadastrar cliente." });
  }
});

// Cadastro restaurante simples (igual ao original)
authRouter.post("/register-restaurante", async (req, res) => {
  let { nome, email, telefone, tipo_cozinha, endereco, senha } = req.body;

  nome = sanitizeString(nome);
  email = sanitizeString(email).toLowerCase();
  telefone = onlyDigits(telefone);
  tipo_cozinha = sanitizeString(tipo_cozinha);
  endereco = sanitizeString(endereco);
  senha = sanitizeString(senha);

  if (!nome || !email || !telefone || !tipo_cozinha || !endereco || !senha) {
    return res.status(400).json({ error: "Preencha todos os campos obrigatórios." });
  }

  if (!isValidEmail(email)) {
    return res.status(400).json({ error: "E-mail inválido." });
  }

  if (telefone.length < 10 || telefone.length > 11) {
    return res.status(400).json({ error: "Telefone inválido." });
  }

  if (senha.length < 6) {
    return res.status(400).json({ error: "Senha muito curta. Mínimo 6 caracteres." });
  }

  try {
    const [r] = await pool.query(
      `INSERT INTO restaurante (nome,email,telefone,tipo_cozinha,endereco,senha_hash)
       VALUES (?,?,?,?,?,?)`,
      [nome, email, telefone, tipo_cozinha, endereco, senha]
    );
    res.status(201).json({ id_restaurante: r.insertId });
  } catch (err) {
    console.error("register-restaurante", err);
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ error: "E-mail ou telefone já cadastrado para outro restaurante." });
    }
    res.status(500).json({ error: "Erro ao cadastrar restaurante." });
  }
});

/* ===================== LOGIN ===================== */

// Login cliente por e-mail
authRouter.post("/login-cliente", async (req, res) => {
  const email = sanitizeString(req.body.email).toLowerCase();
  const senha = sanitizeString(req.body.senha);

  if (!email || !senha) {
    return res.status(400).json({ error: "E-mail e senha são obrigatórios." });
  }

  try {
    const [rows] = await pool.query(
      "SELECT id_cliente,nome,senha_hash FROM cliente WHERE email = ?",
      [email]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Cliente não encontrado." });
    }

    const user = rows[0];
    if (user.senha_hash !== senha) {
      return res.status(401).json({ error: "Senha inválida." });
    }

    res.json({ id_cliente: user.id_cliente, nome: user.nome, role: "cliente" });
  } catch (err) {
    console.error("login-cliente", err);
    res.status(500).json({ error: "Erro ao efetuar login de cliente." });
  }
});

// Login restaurante por e-mail
authRouter.post("/login-restaurante", async (req, res) => {
  const email = sanitizeString(req.body.email).toLowerCase();
  const senha = sanitizeString(req.body.senha);

  if (!email || !senha) {
    return res.status(400).json({ error: "E-mail e senha são obrigatórios." });
  }

  try {
    const [rows] = await pool.query(
      "SELECT id_restaurante,nome,senha_hash FROM restaurante WHERE email = ?",
      [email]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Restaurante não encontrado." });
    }

    const rest = rows[0];
    if (rest.senha_hash !== senha) {
      return res.status(401).json({ error: "Senha inválida." });
    }

    res.json({ id_restaurante: rest.id_restaurante, nome: rest.nome, role: "restaurante" });
  } catch (err) {
    console.error("login-restaurante", err);
    res.status(500).json({ error: "Erro ao efetuar login de restaurante." });
  }
});
